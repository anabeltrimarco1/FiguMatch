function removeDuplicatedText(value) {
  const text = String(value ?? "").trim();

  if (!text) return "";

  const middle = Math.floor(text.length / 2);

  if (
    text.length % 2 === 0 &&
    text.slice(0, middle) === text.slice(middle)
  ) {
    return text.slice(0, middle).trim();
  }

  return text;
}
const stickerName =
  removeDuplicatedText(sticker.name) ||
  `Figurita ${sticker.code}`;

const STATUS_CONFIG = {
  tengo: { label: "Tengo", shortLabel: "Tengo", icon: "✅" },
  repetida: { label: "Repetida", shortLabel: "Repe", icon: "🔁" },
  me_falta: { label: "Me falta", shortLabel: "Falta", icon: "⭕" },
};

const SHIELD_BY_CODE = {
  GER: "alemania.svg", KSA: "arabia saudita.svg", ALG: "argelia.svg",
  ARG: "argentina.svg", AUS: "australia.svg", AUT: "austria.svg",
  BEL: "belgica.svg", BIH: "bosnia y herzegovina.svg", BRA: "brasil.svg",
  CPV: "cabo verde.svg", CAN: "canada.svg", CZE: "chequia.svg",
  COL: "colombia.svg", KOR: "corea del sur.svg", CIV: "costa de marfil.svg",
  CRO: "croacia.svg", CUW: "curazao.svg", ECU: "ecuador.svg",
  EGY: "egipto.svg", SCO: "escocia.svg", ESP: "espana.svg",
  USA: "estados unidos.svg", FRA: "francia.svg", GHA: "ghana.svg",
  HAI: "haiti.svg", ENG: "inglaterra.svg", IRQ: "irak.svg",
  IRN: "iran.svg", JPN: "japon.svg", JOR: "jordania.svg",
  MAR: "marruecos.svg", MEX: "mexico.svg", NOR: "noruega.svg",
  NZL: "nueva zelanda.svg", NED: "paises bajos.svg", PAN: "panama.svg",
  PAR: "paraguay.svg", POR: "portugal.svg", QAT: "qatar.svg",
  COD: "rd congo.svg", SEN: "senegal.svg", RSA: "sudafrica.png",
  SWE: "suecia.svg", SUI: "suiza.png", TUN: "tunez.svg",
  TUR: "turquia.png", URU: "uruguay.svg", UZB: "uzbekistan.svg",
};

function getTeamCode(sticker) {
  return String(sticker.code ?? "").trim().toUpperCase().split(/\s+/)[0];
}

function getShieldPath(sticker) {
  const fileName = SHIELD_BY_CODE[getTeamCode(sticker)];
  return fileName ? `/shields/${fileName}` : null;
}

function getStatusLabel(sticker) {
  const quantity = Number(sticker.quantity) || 0;
  if (sticker.status === "repetida") return quantity > 1 ? `Repetidas ×${quantity}` : "Repetida";
  if (sticker.status === "tengo") return "Tengo";
  return "Me falta";
}

export default function StickerCard({
  sticker,
  savingId,
  updateStatus,
}) {
  const isSaving = savingId === sticker.id;

  const shieldPath = getShieldPath(sticker);

  const currentStatus =
    STATUS_CONFIG[sticker.status] ||
    STATUS_CONFIG.me_falta;

  const stickerName =
    removeDuplicatedText(sticker.name) ||
    `Figurita ${sticker.code}`;

  return (
    <article className={`sticker-card-v11 sprint24 ${sticker.status}`}>
      <div className="sticker-visual-s24">
        <div className="sticker-glow-s24" />
        <span className="sticker-code-badge">{sticker.code}</span>
        <span className={`sticker-status-badge ${sticker.status}`}>
          {currentStatus.icon} {getStatusLabel(sticker)}
        </span>

        <div className="sticker-shield-wrap-s24">
          {shieldPath ? (
            <img
              src={shieldPath}
              alt={`Escudo de ${sticker.team}`}
              className="sticker-placeholder-shield"
              loading="lazy"
              onError={(event) => {
                event.currentTarget.style.display = "none";
                const fallback = event.currentTarget.parentElement?.querySelector(".placeholder-fallback");
                if (fallback) fallback.style.display = "grid";
              }}
            />
          ) : null}
          <span className="placeholder-fallback" style={{ display: shieldPath ? "none" : "grid" }} aria-hidden="true">⚽</span>
        </div>

        <div className="sticker-team-block-s24">
          <span className="sticker-team-label-s24">Selección</span>
          <strong>{sticker.team}</strong>
        </div>
      </div>

      <div className="sticker-info sticker-info-v11">
        <div className="sticker-title-row">
          <div className="sticker-title-content">
            <h3 className="sticker-name">
              {stickerName}
            </h3>
          </div>
          <span className="sticker-number-v11">#{sticker.number}</span>
        </div>

        <div className="sticker-meta-v11">
          <span>{sticker.category || "Figurita"}</span>
          {sticker.group_name && <span>Grupo {sticker.group_name}</span>}
        </div>
      </div>

      <div className="sticker-actions sticker-actions-v11">
        {Object.entries(STATUS_CONFIG).map(([status, config]) => (
          <button
            key={status}
            type="button"
            className={`sticker-status-button ${status} ${sticker.status === status ? "active" : ""}`}
            disabled={isSaving}
            onClick={() => updateStatus(sticker, status)}
            aria-pressed={sticker.status === status}
            title={`Marcar ${sticker.code} como ${config.label}`}
          >
            <span aria-hidden="true">{config.icon}</span>
            <span>{config.shortLabel}</span>
          </button>
        ))}
      </div>

      {isSaving && (
        <div className="sticker-saving-v11" aria-live="polite">
          <span className="sticker-saving-spinner" />
          Guardando...
        </div>
      )}
    </article>
  );
}
