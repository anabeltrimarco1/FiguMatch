import StickerCard from "./StickerCard.jsx";

export default function CardView({ filtered, savingId, updateStatus }) {
  return (
    <section className="card-view-v11">
      <div className="card-view-header">
        <div>
          <span className="card-view-eyebrow">COLECCIÓN</span>
          <h2>Vista de tarjetas</h2>
          <p>Explorá tu colección y actualizá el estado de cada figurita.</p>
        </div>

        <div className="card-view-counter">
          <strong>{filtered.length}</strong>
          <span>figuritas</span>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="card-view-empty">
          <span>🔎</span>
          <h3>No encontramos figuritas</h3>
          <p>Probá cambiar los filtros o la búsqueda.</p>
        </div>
      ) : (
        <div className="sticker-grid sticker-grid-v11">
          {filtered.map((sticker) => (
            <StickerCard
              key={sticker.id}
              sticker={sticker}
              savingId={savingId}
              updateStatus={updateStatus}
            />
          ))}
        </div>
      )}
    </section>
  );
}
